TaskGymTracker - Codemagic-ready ZIP

This ZIP is prepared for Codemagic upload. Upload the whole folder (not the ZIP) or upload the ZIP using Codemagic's 'Build without repository' flow.

On Codemagic use the 'android-build' workflow (it should auto-detect) and start build. After success, download the artifact app-debug.apk.
